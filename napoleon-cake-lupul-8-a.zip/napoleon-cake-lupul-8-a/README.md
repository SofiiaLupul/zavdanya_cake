# Napoleon cake Lupul 8-A

A Pen created on CodePen.

Original URL: [https://codepen.io/hzcjsyai-the-styleful/pen/vEXNJRK](https://codepen.io/hzcjsyai-the-styleful/pen/vEXNJRK).

